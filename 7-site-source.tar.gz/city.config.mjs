export const ACTIVE_CITY = 'waterville-oh';
